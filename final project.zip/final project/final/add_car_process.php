<?php
require_once ('connection.php'); // Include your database connection file
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: adminlogin.php");
    exit();
}

$username = $_SESSION['username'];

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get form data
    $brand = $_POST['brand'];
    $model = $_POST['model'];
    $year = $_POST['year'];
    $color = $_POST['color'];
    $transmission = $_POST['transmission'];
    $fuelType = $_POST['fuelType'];
    $seats = $_POST['seats'];
    $dailyRate = $_POST['dailyRate'];
    $description = $_POST['description'];
    $carImage = $_POST['carImage'];
    $available = $_POST['available'];

    // Insert into cars table
    $sql = "INSERT INTO cars (Brand, Model, Year, Color, Transmission, FuelType, Seats, DailyRate, Description, CarImage, Available) 
            VALUES ('$brand', '$model', '$year', '$color', '$transmission', '$fuelType', '$seats', '$dailyRate', '$description', '$carImage', '$available')";

    if (mysqli_query($con, $sql)) {
        // Car information successfully inserted
        // You can redirect to a success page or display a success message here
        echo " <script>alert('Car information successfully added!')</script>";
        header("Location: mainpage2.php");

    } else {
        // Error occurred while inserting car information
        // You can redirect to an error page or display an error message here
        echo "Error: " . mysqli_error($con);
    }

    // Close database connection
    mysqli_close($con);
}
?>