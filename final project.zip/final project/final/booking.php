<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CAR BOOKING</title>
    <link rel="stylesheet" href="style.css">
    <style>
    body {
            background-image: url("images/book.jpg");
            background-size: cover;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .register {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            height: 300px;
            overflow: auto; /* Add scrollbar if content exceeds container height */
        }
        .register h2 {
            margin-top: 0;
            margin-bottom: 20px;
        }
        .register label {
            font-weight: bold;
        }
        .register input[type="date"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
        }
        .register .btnn {
            background-color: #00E77f;
            color: #fff;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
        }
        .register .btnn:hover {
            background-color: #555;
        }
    </style>
</head>
<body background="images/book.jpg">
<?php
// session_start();
require_once('connection.php');

if (isset($_GET['id'])) {
    $carid = $_GET['id'];
    $sql = "SELECT * FROM cars WHERE CarID='$carid'";
    $cname = mysqli_query($con, $sql);
    $email = mysqli_fetch_assoc($cname);

    if ($email) {
        $carprice = $email['DailyRate'];
    } else {
        die('Car not found.');
    }
} else {
    die('Car ID not provided.');
}

if (isset($_SESSION['email'])) {
    $value = $_SESSION['email'];
    $sql = "SELECT * FROM student WHERE Email='$value'";
    $name = mysqli_query($con, $sql);
    $rows = mysqli_fetch_assoc($name);
    $uemail = $rows['email'];
} else {
    die('User email not found in session.');
}

if (isset($_POST['book'])) {
    $bdate = date('Y-m-d', strtotime($_POST['date']));
    $rdate = date('Y-m-d', strtotime($_POST['rdate']));

    if (empty($bdate) || empty($rdate)) {
        echo '<script>alert("Please fill in all fields")</script>';
    } else {
        if ($bdate < $rdate) {
            $dur = ceil(abs(strtotime($rdate) - strtotime($bdate)) / (60 * 60 * 24));
            $price = $dur * $carprice;
            $sql = "INSERT INTO bookings (CarID, email, bookdate, RETURN_DATE, PRICE) 
                    VALUES ($carid, '$uemail', '$bdate', '$rdate', $price)";
            $result = mysqli_query($con, $sql);
            if ($result) {
                echo '<script>alert("Booking successful!")</script>';
                echo '<script>window.location = "mainpage.php";</script>'; // Redirect to same page after alert
                exit();
            } else {
                echo '<script>alert("Error: ' . mysqli_error($con) . '")</script>'; // Display MySQL error
            }
        } else {
            echo '<script>alert("Please enter a correct return date")</script>';
        }
    }
}
?>

<header class="header">
    <section class="flex">
        <a href="#" class="logo">Cars</a>
        <nav class="navbar">
            <!-- <a href="#"></a>
            <a href="#">H</a>
            <a href="#">HOME</a> -->
            <a href="mainpage.php">HOME</a>
            <a href=""> hi, <?php echo $rows['username'] ?></a>
        </nav>
        <div id="menu-btn" class="fas fa-bars"></div>
    </section>
</header>
<div class="main">
    <div class="register">
        <h2>BOOKING</h2>
        <form id="register" method="POST">
            <h3>CAR NAME : <?php echo $email['Brand']; ?></h3>
            <p>DAILY RENT AMOUNT: <?php echo $carprice; ?></p> <!-- Display daily rent amount here -->
            <label>BOOKING DATE : </label>
            <br>
            <input type="date" name="date" id="datefield" min='1899-01-01' max='2000-13-13' placeholder="ENTER THE DATE FOR BOOKING">
            <br>
            <label>Return date : </label>
            <br>
            <input type="date" name="rdate" id="dfield" min='1899-01-01' placeholder="Enter The Return Date" onchange="calculatePrice()">
            <br><br>
            <label>Price: </label>
            <span id="price">0</span>
            <br><br>
            <input type="submit" class="btnn" value="BOOK" name="book">
        </form>
    </div>
</div>

<script>
    function calculatePrice() {
        var startDate = document.getElementById("datefield").value;
        var endDate = document.getElementById("dfield").value;

        if (startDate && endDate) {
            var start = new Date(startDate);
            var end = new Date(endDate);
            var diffInDays = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
            var carPrice = <?php echo $carprice; ?>;
            var totalPrice = diffInDays * carPrice;
            document.getElementById("price").innerText = totalPrice;
        }
    }
</script>
</body>
</html>
