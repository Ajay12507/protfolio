<?php
require_once('connection.php');

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $bookid = $_GET['id'];
    $sql = "SELECT * FROM bookings WHERE id = $bookid";
    $result = mysqli_query($con, $sql);
    $res = mysqli_fetch_assoc($result);

    if ($res['booking_status'] == 'APPROVED' || $res['booking_status'] == 'RETURNED') {
        echo '<script>alert("Cannot cancel. Booking already approved or returned.")</script>';
        echo '<script>window.location.href = "bookingadmin.php";</script>';
    } else {
        // Update the booking status to "Cancelled"
        $query = "UPDATE bookings SET booking_status = 'Cancelled' WHERE id = $bookid";
        $queryy = mysqli_query($con, $query);

        // Mark the car as available again
        $carid = $res['CarID'];
        $sql_update_car = "UPDATE cars SET Available = 'Y' WHERE CarID = $carid";
        mysqli_query($con, $sql_update_car);

        echo '<script>alert("Booking cancelled successfully")</script>';
        echo '<script>window.location.href = "bookingadmin.php";</script>';
    }
} else {
    echo '<script>alert("Invalid request!")</script>';
    echo '<script>window.location.href = "bookingadmin.php";</script>';
}
?>

