<?php
session_start(); // Start the session

// Initialize variables
$message = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmpassword = $_POST['confirmpassword'];

    // Establish database connection
    $conn = mysqli_connect('localhost', 'root', '', 'MCACAR');

    if (!$conn) {
        die("CONNECTION FAILED: " . mysqli_connect_error());
    }

    // Prepare and execute statements to check for existing usernames and emails
    $stmt_name = mysqli_prepare($conn, "SELECT username FROM student WHERE username=?");
    mysqli_stmt_bind_param($stmt_name, "s", $name);
    mysqli_stmt_execute($stmt_name);
    mysqli_stmt_store_result($stmt_name);
    $count_name = mysqli_stmt_num_rows($stmt_name);

    $stmt_email = mysqli_prepare($conn, "SELECT email FROM student WHERE email=?");
    mysqli_stmt_bind_param($stmt_email, "s", $email);
    mysqli_stmt_execute($stmt_email);
    mysqli_stmt_store_result($stmt_email);
    $count_email = mysqli_stmt_num_rows($stmt_email);

    // Check if username or email already exists
    if ($count_name > 0) {
        $message = 'Your username is already taken';
    } elseif ($count_email > 0) {
        $message = 'Your email is already taken';
    } elseif ($password !== $confirmpassword) {
        // Check if passwords match
        $message = 'Passwords do not match';
    } else {
        // Hash the password
        $hashed_password = sha1($password);

        // Prepare and execute statement to insert new user data
        $stmt_insert = mysqli_prepare($conn, "INSERT INTO `student`(`username`, `email`, `password`) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt_insert, "sss", $name, $email, $hashed_password);

        $query_result = mysqli_stmt_execute($stmt_insert);

        if ($query_result) {
            // Registration successful
            $_SESSION['message'] = 'Registration successful'; // Store success message in session
            header("Location: " . $_SERVER['PHP_SELF']); // Redirect to same page to prevent resubmission
            exit();
        } else {
            // Registration failed
            $message = 'Registration failed';
        }
    }

    // Close statements
    mysqli_stmt_close($stmt_name);
    mysqli_stmt_close($stmt_email);

    if (isset($stmt_insert)) {
        mysqli_stmt_close($stmt_insert);
    }

    mysqli_close($conn);
}

if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']); 
}

if (!empty($message)) {
    echo "<p>$message</p>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="register.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Student Registration</title>
</head>

<body>
    <header class="header">
        <section class="flex">
            <a href="#" class="logo">CARs.</a>
            <nav class="navbar">
                <a href="index.php">HOME</a>
                <a href="">CONTACT US</a>
                <a href="login.php">LOGIN</a>
            </nav>
            <div id="menu-btn" class="fas fa-bars"></div>
        </section>
    </header>

    <section class="registration-form">
        <div class="form-container">
            <h2>Registration</h2>
            <form action="register.php" method="post" name="form" id="form">
                <?php if (!empty($message)) : ?>
                    <div><?php echo $message; ?></div>
                <?php endif; ?>
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required placeholder="name"><br><br>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required placeholder="email"><br><br>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required placeholder="password"><br><br>
                <label for="confirm-password">Confirm Password:</label>
                <input type="password" id="confirmpassword" name="confirmpassword" required placeholder="confirm-password"><br><br>
                <input type="submit" name="register" id="submit" value="register">
            </form>
        </div>

    </section>
    <div class="form-container" style="border: none;text-align: center; box-shadow: none;width:100%; ">
        <a href="https://www.facebook.com/YourPage" target="_blank" class="facebook"><i class="fab fa-facebook-f"></i></a>
        <a href="https://www.instagram.com/YourPage" target="_blank" class="instagram"><i class="fab fa-instagram"></i></a>
        <a href="https://twitter.com/YourPage" target="_blank" class="twitter"><i class="fab fa-twitter"></i></a>
    </div>
</body>

</html>