<?php
session_start();
$message = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Database connection
    $conn = mysqli_connect('localhost', 'root', '', 'MCACAR');
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Secure the data
    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);
    // $password = sha1($password); // Hash the entered password (not recommended, consider using more secure methods)

    // Query to check user credentials
    $query = "SELECT * FROM admin WHERE username='$username' AND password='$password' LIMIT 1";
    $result = mysqli_query($conn, $query);

    if (!$result || mysqli_num_rows($result) == 0) {
        $message = "The information you entered was incorrect!";
    } else {
        // Start the session
        $row = mysqli_fetch_assoc($result);
        $_SESSION['username'] = $username;
        $_SESSION['id'] = $row['id'];

        // Redirect to index.php after successful login
        header("Location: mainpage2.php");
        exit();
    }

    mysqli_close($conn);
} 

if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']); // Remove the message from session after displaying it
}

// Display the error message
if (!empty($message)) {
    echo "<p>$message</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="register.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Student Login</title>
</head>
<body style="background-color: black;">
    <!-- header section start -->
    <header class="header" style="background-color:black; color:black; box-shadow:0px 0px 5px 0px white;">
         <section class="flex">
            <a href="mainpage2.php" class="logo">CARS RENT</a>
            <nav class="navbar">
                <a href="index.php">HOME</a>
                <a href="">REVIEWS</a>
                <!-- <a href="">CONTACT US</a> -->
                <a href="register.php">REGISTER</a>
            </nav>
            <div id="menu-btn" class="fas fa-bars"></div>
        </section>
    </header> 

    <!-- Login form -->
    <section class="registration-form" style="top: 10px;">
        <div class="form-container" style="top: 10px;">
            <h2>admin Login</h2>
            <form action="adminlogin.php" method="POST">
                <?php if (!empty($message)) : ?>
                    <div><?php echo $message; ?></div>
                <?php endif; ?>
                <label for="username">username:</label>
                <input type="text" id="username" name="username" required><br><br>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                <input class="button" type="submit" id="submit" name="login" value="Login">
                <br><br>
            </form>
        </div>
    </section>
    </div>
</body>
</html>
