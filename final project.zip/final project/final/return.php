<?php
require_once('connection.php');

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $bookid = $_GET['id'];
    $sql = "SELECT * FROM bookings WHERE id = $bookid";
    $result = mysqli_query($con, $sql);
    $res = mysqli_fetch_assoc($result);
    $car_id = $res['CarID'];
    $sql2 = "SELECT * FROM cars WHERE CarID = $car_id";
    $carres = mysqli_query($con, $sql2);
    $carresult = mysqli_fetch_assoc($carres);
    
    if ($carresult['Available'] == 'Y') {
        if ($res['booking_status'] == 'APPROVED') {
            $query = "UPDATE bookings SET booking_status = 'RETURNED' WHERE id = $bookid";
            $queryy = mysqli_query($con, $query);
            
            // Mark the car as available again
            $sql_update_car = "UPDATE cars SET Available = 'Y' WHERE CarID = $car_id";
            mysqli_query($con, $sql_update_car);

            echo '<script>alert("Car marked as returned successfully")</script>';
            echo '<script>window.location.href = "bookingadmin.php";</script>';
        } else {
            echo '<script>alert("Cannot mark car as returned. Booking status is not approved.")</script>';
            echo '<script>window.location.href = "bookingadmin.php";</script>';
        }
    } else {
        echo '<script>alert("CAR IS NOT AVAILABLE")</script>';
        echo '<script>window.location.href = "bookingadmin.php";</script>';
    }
} else {
    echo '<script>alert("Invalid request!")</script>';
    echo '<script>window.location.href = "bookingadmin.php";</script>';
}
?>
