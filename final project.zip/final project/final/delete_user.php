<?php
require_once('connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_user'])) {
    // Check if user_id is set and numeric
    if (isset($_POST['user_id']) && is_numeric($_POST['user_id'])) {
        $user_id = $_POST['user_id'];

        // Check if the user has associated bookings
        $sql_check_bookings = "SELECT COUNT(*) AS num_bookings FROM bookings WHERE email = (SELECT email FROM student WHERE id = ?)";
        $stmt_check_bookings = mysqli_prepare($con, $sql_check_bookings);
        mysqli_stmt_bind_param($stmt_check_bookings, "i", $user_id);
        mysqli_stmt_execute($stmt_check_bookings);
        $result_check_bookings = mysqli_stmt_get_result($stmt_check_bookings);
        $row_check_bookings = mysqli_fetch_assoc($result_check_bookings);
        $num_bookings = $row_check_bookings['num_bookings'];

        if ($num_bookings > 0) {
            // User has associated bookings, display alert
            echo '<script>alert("This user cannot be deleted because they have associated bookings."); window.location.href = "useradmin.php";</script>';
        } else {
            // No associated bookings, proceed with deletion
            $sql_delete_user = "DELETE FROM student WHERE id = ?";
            $stmt_delete_user = mysqli_prepare($con, $sql_delete_user);
            mysqli_stmt_bind_param($stmt_delete_user, "i", $user_id);

            if (mysqli_stmt_execute($stmt_delete_user)) {
                // User deleted successfully
                echo '<script>alert("User deleted successfully."); window.location.href = "useradmin.php";</script>';
            } else {
                // Error occurred while deleting user
                echo '<script>alert("Error occurred while deleting user. Please try again later."); window.location.href = "useradmin.php";</script>';
            }

            // Close statement
            mysqli_stmt_close($stmt_delete_user);
        }

        // Close statements and connection
        mysqli_stmt_close($stmt_check_bookings);
        mysqli_close($con);
    }
}
?>
