<?php
require_once('connection.php');
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: adminlogin.php");
    exit();
}

$username = $_SESSION['username'];

// Query to get all bookings with car details and user email
$sql_all_bookings = "SELECT bookings.id, 
cars.Brand, 
cars.Model, 
bookings.bookdate, 
bookings.RETURN_DATE, 
bookings.PRICE, 
bookings.booking_status, 
bookings.email,
student.username 
FROM bookings 
INNER JOIN cars ON bookings.CarID = cars.CarID 
INNER JOIN student ON bookings.email = student.email;
";
$result_all_bookings = mysqli_query($con, $sql_all_bookings);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminstyle.css">
    <title>Admin Dashboard</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <!-- header section start -->
    <header class="header">
        <section class="flex">
            <a href="#" class="logo">CARs.</a>
            <nav class="navbar">
                <a href="#">Welcome, <?php echo $username; ?></>
                    <a href="mainpage2.php">CARS</a>
                    <a href="useradmin.php">USESR</a>
                    <a href="">BOOKINS</a>
            </nav>
            <div id="menu-btn" class="fas fa-bars"></div>
        </section>
    </header>
    <section class="home" id="home">
        <div class="row">
            <div class="content">
            </div>
        </div>
    </section>
    <section class="all-bookings" style="font-size:2rem;">
        <h2>Bookings</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NAME</th>
                    <th>EMAIL</th>
                    <th>CAR</th>
                    <th>BOOKDATE</th>
                    <th>RETURNDATE</th>
                    <th>Price</th>
                    <th>STAUS</th>
                    <th>ACTION</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result_all_bookings)) : ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['Brand'], "-" . $row['Model'];; ?></td>
                        <td><?php echo $row['bookdate']; ?></td>
                        <td><?php echo $row['RETURN_DATE']; ?></td>
                        <td><?php echo $row['PRICE']; ?></td>
                        <td><?php echo $row['booking_status']; ?></td>
                        <td>
                            <button type="submit" class="but" name="approve"><a href="approve.php?id=<?php echo $row['id'] ?>">APPROVE</a></button>
                            <button type="submit" class="but" name="approve"><a href="cancel.php?id=<?php echo $row['id'] ?>">CANCEL</a></button>
                        </td>
                        </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </section>
</body>

</html>