<?php
session_start();
$message = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Database connection
    $conn = mysqli_connect('localhost', 'root', '', 'MCACAR');
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Secure the data
    $email = mysqli_real_escape_string($conn, $email);
    $password = mysqli_real_escape_string($conn, $password);
    $password = sha1($password); // Hash the entered password (not recommended, consider using more secure methods)

    // Query to check user credentials
    $query = "SELECT * FROM student WHERE email='$email' AND password='$password' LIMIT 1";
    $result = mysqli_query($conn, $query);

    if (!$result || mysqli_num_rows($result) == 0) {
        $message = "The information you entered was incorrect!";
    } else {
        // Start the session
        $row = mysqli_fetch_assoc($result);
        $_SESSION['email'] = $row['email'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['id'] = $row['id'];

        // Redirect to index.php after successful login
        header("Location: mainpage.php");
        exit();
    }

    mysqli_close($conn);
} 

if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']); // Remove the message from session after displaying it
}

// Display the error message
if (!empty($message)) {
    echo "<p>$message</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="register.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Login here</title>
</head>
<body style="background-color:black;">
    <!-- header section start -->
    <header class="header" style="box-shadow:0px 0px 5px 0px white;">
        <section class="flex">
            <a href="#" class="logo">CARS.</a>
            <nav class="navbar">
                <a href="index.php">HOME</a>
                <a href="register.php">REGISTER</a>
            </nav>
            <div id="menu-btn" class="fas fa-bars"></div>
        </section>
    </header>

    <!-- Login form -->
    <section class="registration-form">
        <div class="form-container">
            <h2>User Login</h2>
            <form action="login.php" method="POST">
                <?php if (!empty($message)) : ?>
                    <div><?php echo $message; ?></div>
                <?php endif; ?>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required placeholder="email"><br><br>
                <label for="password" >Password:</label>
                <input type="password" id="password" name="password" required placeholder="password">
                <input class="button" type="submit" id="submit" name="login" value="Login">
                <br><br>
            </form>
        </div>
        
    </section>
    <div class="form-container" style="border: none;text-align: center; box-shadow: none;width:100%; ">
    <a href="https://www.facebook.com/YourPage" target="_blank" class="facebook"><i class="fab fa-facebook-f"></i></a>
    <a href="https://www.instagram.com/YourPage" target="_blank" class="instagram"><i class="fab fa-instagram"></i></a>
    <a href="https://twitter.com/YourPage" target="_blank" class="twitter"><i class="fab fa-twitter"></i></a>
    </div>
</body>
</html>
