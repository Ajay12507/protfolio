<?php
require_once('connection.php');
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: adminlogin.php");
    exit();
}

$username = $_SESSION['username'];

$sql_students = "SELECT COUNT(*) AS total_students FROM student";
$result_students = mysqli_query($con, $sql_students);
$row_students = mysqli_fetch_assoc($result_students);
$total_students = $row_students['total_students'];

$sql_all_user = "SELECT * FROM student";
$result_all_user = mysqli_query($con, $sql_all_user);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminstyle.css">
    <title>Admin Dashboard</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <header class="header">
        <section class="flex">
            <a href="#" class="logo">CARs.</a>
            <nav class="navbar">
                <a href="#">Welcome, <?php echo $username; ?></>
                    <a href="mainpage2.php">Cars</a>
                    <a href="useradmin.php">USESR</a>
                    <a href="bookingadmin.php">BOOKINS</a>
            </nav>
            <div id="menu-btn" class="fas fa-bars"></div>
        </section>
    </header>
    <section class="home" id="home">
        <div class="row">
            <div class="content">
            </div>
        </div>
    </section>
    <section class="all-user" style="font-size:2rem;">
        <h2>user</h2>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>BRAND</th>
                    <th>BRAND</th>
                    <th>ACTION</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result_all_user)) : ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['email']; ?></td>

                        <td>
                            <form action="delete_user.php" method="POST">
                                <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="delete_user">Delete</button>
                            </form>

                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </section>