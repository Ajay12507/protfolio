<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
    <style>


    </style>
</head>

<body style="background-color: black;">
    <header class="header" style="background-color: black;box-shadow:0px 0px 5px 0px white;">
        <section class="flex">
            <a href="#" class="logo">CARs.</a>
            <nav class="navbar">
                <a href="login.php">LOGIN</a>
                <a href="register.php">REGISTER</a>
                <a href="adminlogin.php">ADMIN</a>
            </nav>
            <div id="menu-btn" class="fas fa-bars"></div>
        </section>
    </header>
    <section class="home" id="home">
        <div class="row">
            <div class="content">
                <br><br>
                <h3>join us <br><span>FOR YOUR DESIRE CARS</span></h3>
               
                <div class="content" style="font-size: 20px;">
                <span>
                    <!-- <h4 style="color: aqua;">Experience the Freedom of the Open Road with CARs
                    At CARs, we believe in making your journey as smooth and enjoyable as possible.
                    Whether you're planning a weekend getaway, a business trip, or a cross-country
                    adventure, we have the perfect car to meet your needs.</h4> -->
                </span>
            </div style="padding: 10px;">
            <a href="register.php" class="btn" style="top: 10px;">JOIN US</a>
            </div>
           
        </div>
    </section>
    <br><br><br><br><br>
    <section class="count">
        <div class="box-container">
            <div class="box">
                <i class="fas fa-graduation-cap"></i>
                <div class="content">
                    <h3>150+</h3>
                    <p>CARS</p>
                </div>
            </div>
            <div class="box">
                <i class="fas fa-user-graduate"></i>
                <div class="content">
                    <h3>30+</h3>
                    <p>STATES</p>
                </div>
            </div>
            <div class="box">
                <i class="fas fa-user-graduate"></i>
                <div class="content">
                    <h3>24x7</h3>
                    <p>SERVICE</p>
                </div>
            </div>
        </div>
    </section>
    <script src="script.js"></script>
</body>

</html>