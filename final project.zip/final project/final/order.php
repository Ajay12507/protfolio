<?php
require_once('connection.php');
session_start();

// Check if the email session variable is set
if (isset($_SESSION['email'])) {
    $value = $_SESSION['email'];

    // Query to get student details
    $sql = "SELECT * FROM student WHERE email='$value'";
    $name = mysqli_query($con, $sql);
    $rows = mysqli_fetch_assoc($name); // Fetch student details

    // Query to get bookings for the user
    $sql2 = "SELECT * FROM bookings WHERE email='$value'";
    $bookings_result = mysqli_query($con, $sql2);

    // Check if the bookings query executed successfully
    if ($bookings_result) {
        // Fetch bookings data
        $bookings = array();
        while ($row = mysqli_fetch_assoc($bookings_result)) {
            $bookings[] = $row;
        }
    } else {
        // Handle query execution failure
        echo "Error retrieving bookings: " . mysqli_error($con);
        // Initialize $bookings as an empty array
        $bookings = array();
    }
} else {
    // Handle session variable not set
    echo "Session email not set.";
    // Initialize $rows as an empty array
    $rows = array();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="booking.css">
    <title>Your Bookings</title>
    <style>
        .booking-item{
           /* position: absolute; */
           display:inline-block;
           margin-left: 5px;

        }
    </style>
</head>
<body>
    <header class="header">
        <section class="flex">
            <a href="#" class="logo">Educa.</a>
            <nav class="navbar">
                <a href="mainpage.php">HOME</a>
                <a href="#">BOOKINGS</a>
                <a href="">Hi, <?php echo isset($rows['username']) ? $rows['username'] : "Guest"; ?></a>
                <a href="index.php">LOGOUT</a>

            </nav>
            <div id="menu-btn" class="fas fa-bars"></div>
        </section>
    </header>
    <section class="home" id="home">

    </section>

    <section class="bookings" id="bookings">
        <h1 class="heading">Your <span>Bookings</span> </h1>
        <div class="booking-list">
            <?php foreach ($bookings as $booking) : ?>
                <div class="booking-item" style="font-size: 15px;border:1px solid aquamarine;padding:25px; background-color:white; width:fit-content;margin-bottom:20px; ">
                    <h2>Booking ID: <?php echo $booking['id']; ?></h2>
                    <p>Car ID: <?php echo $booking['CarID']; ?></p>
                    <p>Booking Date: <?php echo $booking['bookdate']; ?></p>
                    <p>Return Date: <?php echo $booking['RETURN_DATE']; ?></p>
                    <p>Price: <?php echo $booking['PRICE']; ?></p>
                    <p>Status: <?php echo $booking['booking_status']; ?></p>
                    
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <script src="script.js"> </script>
</body>
</html>
