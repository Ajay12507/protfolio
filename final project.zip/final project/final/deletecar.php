<?php
require_once('connection.php');

// Check if CarID is provided in the URL
if(isset($_GET['id'])) {
    $carid = $_GET['id'];

    // Check if there are any bookings associated with the car
    $sql_check_bookings = "SELECT COUNT(*) AS num_bookings FROM bookings WHERE CarID = $carid";
    $result_check_bookings = mysqli_query($con, $sql_check_bookings);
    $row_check_bookings = mysqli_fetch_assoc($result_check_bookings);
    $num_bookings = $row_check_bookings['num_bookings'];

    if($num_bookings > 0) {
        // Bookings exist for the car, display a message
        echo '<script>alert("Cannot delete the car because there are booking orders associated with it.")</script>';
        echo '<script>window.location.href = "mainpage2.php";</script>';
    } else {
        // No bookings associated with the car, proceed with deletion
        $sql_delete_car = "DELETE FROM cars WHERE CarID = $carid";
        $result_delete_car = mysqli_query($con, $sql_delete_car);

        if($result_delete_car) {
            // Car successfully deleted
            echo '<script>alert("CAR DELETED SUCCESSFULLY")</script>';
            echo '<script>window.location.href = "mainpage2.php";</script>';
        } else {
            // Error occurred while deleting car
            echo '<script>alert("ERROR: ' . mysqli_error($con) . '")</script>';
            echo '<script>window.location.href = "mainpage2.php";</script>';
        }
    }
} else {
    // CarID not provided in the URL
    echo '<script>alert("ERROR: CarID not provided in the URL")</script>';
    echo '<script>window.location.href = "mainpage2.php";</script>';
}
?>
