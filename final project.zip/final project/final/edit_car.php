<?php
require_once('connection.php'); // Include your database connection file
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: adminlogin.php");
    exit();
}

$username = $_SESSION['username'];

// Get CarID from the URL
$carID = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch car data
$sql = "SELECT * FROM cars WHERE CarID = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("i", $carID);
$stmt->execute();
$result = $stmt->get_result();
$car = $result->fetch_assoc();

if (!$car) {
    echo "Car not found!";
    exit;
}

// Check if the form is submitted
$updateSuccess = false;
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get form data
    $brand = $_POST['brand'];
    $model = $_POST['model'];
    $year = $_POST['year'];
    $color = $_POST['color'];
    $transmission = $_POST['transmission'];
    $fuelType = $_POST['fuelType'];
    $seats = $_POST['seats'];
    $dailyRate = $_POST['dailyRate'];
    $description = $_POST['description'];
    $available = $_POST['available'];

    // Handle file upload if a new image is provided
    if (isset($_FILES['carImage']) && $_FILES['carImage']['error'] == UPLOAD_ERR_OK) {
        $carImage = 'uploads/' . basename($_FILES['carImage']['name']);
        move_uploaded_file($_FILES['carImage']['tmp_name'], $carImage);
    } else {
        $carImage = $car['CarImage'];
    }

    // Update car data
    $sql = "UPDATE cars SET Brand=?, Model=?, Year=?, Color=?, Transmission=?, FuelType=?, Seats=?, DailyRate=?, Description=?, CarImage=?, Available=? WHERE CarID=?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ssisssisissi", $brand, $model, $year, $color, $transmission, $fuelType, $seats, $dailyRate, $description, $carImage, $available, $carID);

    if ($stmt->execute()) {
        $updateSuccess = true;
        // Refresh car data
        $stmt = $con->prepare("SELECT * FROM cars WHERE CarID = ?");
        $stmt->bind_param("i", $carID);
        $stmt->execute();
        $result = $stmt->get_result();
        $car = $result->fetch_assoc();
    } else {
        echo "Error updating car: " . $con->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="register.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Edit Car</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        .header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            text-decoration: none;
            color: #fff;
        }

        .navbar {
            display: inline-block;
            margin-left: 20px;
        }

        .navbar a {
            color: #fff;
            text-decoration: none;
            margin-left: 10px;
        }

        .flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            margin: auto;
            margin-top: 50px;
        }

        .form-container h2 {
            margin-bottom: 20px;
            text-align: center;
        }

        .form-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .form-row div {
            width: 48%;
        }

        .form-row input,
        .form-row select,
        .form-row textarea,
        .form-row button {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 14px;
        }

        .form-row textarea {
            height: 80px;
        }

        .form-row button[type="submit"] {
            width: 100%;
            display: block;
            margin: auto;
            background-color: #333;
            color: #fff;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        .form-row button[type="submit"]:hover {
            background-color: #555;
        }

        .success-message {
            color: green;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- header section start -->
    <header class="header">
        <div class="flex">
            <a href="#" class="logo">CARS.</a>
            <nav class="navbar">
                <a href=""></a>
                <a href=""></a>
                <a href=""></a>
                <a href=""></a>
            </nav>
            <div id="menu-btn" class="fas fa-bars"></div>
        </div>
    </header>

    <!-- Edit car form -->
    <section class="form-container">
        <h2>Edit Car</h2>
        <?php if ($updateSuccess): ?>
            <p class="success-message">Car information successfully updated!</p>
        <?php endif; ?>
        <form action="edit_car.php?id=<?php echo $carID; ?>" method="POST" enctype="multipart/form-data">
            <div class="form-row">
                <div>
                    <label for="brand">Brand:</label>
                    <input type="text" id="brand" name="brand" value="<?php echo htmlspecialchars($car['Brand']); ?>" required>
                </div>
                <div>
                    <label for="model">Model:</label>
                    <input type="text" id="model" name="model" value="<?php echo htmlspecialchars($car['Model']); ?>" required>
                </div>
            </div>
            <div class="form-row">
                <div>
                    <label for="year">Year:</label>
                    <input type="number" id="year" name="year" value="<?php echo htmlspecialchars($car['Year']); ?>" required>
                </div>
                <div>
                    <label for="color">Color:</label>
                    <input type="text" id="color" name="color" value="<?php echo htmlspecialchars($car['Color']); ?>" required>
                </div>
            </div>
            <div class="form-row">
                <div>
                    <label for="transmission">Transmission:</label>
                    <input type="text" id="transmission" name="transmission" value="<?php echo htmlspecialchars($car['Transmission']); ?>" required>
                </div>
                <div>
                    <label for="fuelType">Fuel Type:</label>
                    <input type="text" id="fuelType" name="fuelType" value="<?php echo htmlspecialchars($car['FuelType']); ?>" required>
                </div>
            </div>
            <div class="form-row">
                <div>
                    <label for="seats">Seats:</label>
                    <input type="number" id="seats" name="seats" value="<?php echo htmlspecialchars($car['Seats']); ?>" required>
                </div>
                <div>
                    <label for="dailyRate">Daily Rate:</label>
                    <input type="text" id="dailyRate" name="dailyRate" value="<?php echo htmlspecialchars($car['DailyRate']); ?>" required>
                </div>
            </div>
            <div class="form-row">
                <div>
                    <label for="description">Description:</label>
                    <textarea id="description" name="description" rows="4" required><?php echo htmlspecialchars($car['Description']); ?></textarea>
                </div>
                <div>
                    <label for="carImage">Car Image:</label>
                    <input type="file" id="carImage" name="carImage" accept="image/*">
                </div>
            </div>
            <div class="form-row">
                <div>
                <label for="available">Available:</label>
                    <select id="available" name="available" required>
                        <option value="Y" <?php if ($car['Available'] == 'Y') echo 'selected'; ?>>Yes</option>
                        <option value="N" <?php if ($car['Available'] == 'N') echo 'selected'; ?>>No</option>
                    </select>
                </div>
                <div>
                    <button type="submit">Update Car</button>
                </div>
            </div>
        </form>
    </section>
</body>
</html>

