<?php
require_once('connection.php');
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: adminlogin.php");
    exit();
}

$username = $_SESSION['username'];

// Query to count total students
$sql_students = "SELECT COUNT(*) AS total_students FROM student";
$result_students = mysqli_query($con, $sql_students);
$row_students = mysqli_fetch_assoc($result_students);
$total_students = $row_students['total_students'];

// Query to count total cars
$sql_cars = "SELECT COUNT(*) AS total_cars FROM cars";
$result_cars = mysqli_query($con, $sql_cars);
$row_cars = mysqli_fetch_assoc($result_cars);
$total_cars = $row_cars['total_cars'];

// Query to count total bookings
$sql_bookings = "SELECT COUNT(*) AS total_bookings FROM bookings";
$result_bookings = mysqli_query($con, $sql_bookings);
$row_bookings = mysqli_fetch_assoc($result_bookings);
$total_bookings = $row_bookings['total_bookings'];

// Query to get all cars
$sql_all_cars = "SELECT * FROM cars";
$result_all_cars = mysqli_query($con, $sql_all_cars);

$sql_all_user = "SELECT * FROM student";
$result_all_user = mysqli_query($con, $sql_all_user);

$sql_all_bookings = "SELECT * FROM bookings";
$result_all_bookings = mysqli_query($con, $sql_all_bookings);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminstyle.css">
    <title>Admin Dashboard</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <!-- header section start -->
    <header class="header">
        <section class="flex">
            <a href="#" class="logo">CARs.</a>
            <nav class="navbar">
                <a href="#">Welcome, <?php echo $username; ?></>
                    <a href="">CARS</a>
                    <a href="useradmin.php">USESR</a>
                    <a href="bookingadmin.php">BOOKINS</a>
            </nav>
            <div id="menu-btn" class="fas fa-bars"></div>
        </section>
    </header>
    <section class="home" id="home">
        <div class="row">
            <div class="content">

            </div>

        </div>
    </section>
    <section class="all-cars" style="font-size:2rem;">
        <h2>Cars</h2>

        <button onclick="window.location.href='add_car.php'">Add New Car</button>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>BRAND</th>
                    <th>MODEL</th>
                    <th>YEAR</th>
                    <th>COLOR</th>
                    <th>TRANSMISSION</th>
                    <th>FUEL TYPE</th>
                    <th>SEATS</th>
                    <th>RATE</th>
                    <th>AVAILABILITY</th>
                    <th>ACTIONS</th> <!-- Add this column for buttons -->
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result_all_cars)) : ?>
                    <tr>
                        <td><?php echo $row['CarID']; ?></td>
                        <td><?php echo $row['Brand']; ?></td>
                        <td><?php echo $row['Model']; ?></td>
                        <td><?php echo $row['Year']; ?></td>
                        <td><?php echo $row['Color']; ?></td>
                        <td><?php echo $row['Transmission']; ?></td>
                        <td><?php echo $row['FuelType']; ?></td>
                        <td><?php echo $row['Seats']; ?></td>
                        <td><?php echo $row['DailyRate']; ?></td>
                        <td>
                            <center><?php echo $row['Available']; ?></center>
                        </td>
                        <td>
                            <a href="edit_car.php?id=<?php echo $row['CarID'] ?>">
                                <button type="button">Edit</button>
                            </a>
                            <button type="submit" class="but" name="approve">
                                <a href="deletecar.php?id=<?php echo $row['CarID'] ?>">DELETE CAR</a>
                            </button>

                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </section>