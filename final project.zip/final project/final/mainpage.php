<?php
require_once('connection.php');
session_start();

$value = $_SESSION['email'];

$sql = "SELECT * FROM student WHERE email='$value'";
$name = mysqli_query($con, $sql);
$rows = mysqli_fetch_assoc($name);

$sql2 = "SELECT * FROM cars WHERE AVAILABLE='Y'";
$cars = mysqli_query($con, $sql2);

echo "Redirected email: " . $value . "<br>";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>
    <header class="header">
        <section class="flex">
            <a href="#" class="logo">CARS RENT</a>
            <nav class="navbar">
                <a href="#">HOME</a>
                <a href="order.php">BOOKINGS</a>
                <a href=""> hi, <?php echo $rows['username'] ?></a>
                <a href="index.php">LOGOUT</a>

            </nav>
            <div id="menu-btn" class="fas fa-bars"></div>
        </section>
    </header>
    <section class="home" id="home">

    </section>

    <section class="courses" id="courses">

        <h1 class="heading">our <span>Cars</span> </h1><br>
        <br><br>
        <div class="w">
            <?php while ($result = mysqli_fetch_array($cars) ) { ?>
                <div class="slide" style="font-size: 20px; background-color:#fff;text-align:left;">
                    
                   <center> <img src="images/<?php echo $result['CarImage'] ?>"><br></center>
                    <?php $res = $result['CarID']; ?> 
                    <label for="brand">car name :
                    <?php echo $result['Brand'] ?></label><br>
               
                    <label for="brand">FuelType :
                    <?php echo $result['FuelType'] ?></label><br>
                    
                    <label for="brand">Capacity :
                    <?php echo $result['Seats'] ?></label><br>
                    
                    <label for="brand">Per km :
                    <?php echo $result['DailyRate'] ?></label><br>
                    
                    <label for="brand">Description :
                    <?php echo $result['Description'] ?></label><br><br><center>
                    <button type="submit" name="booknow" class="custom-button"><a href="booking.php?id=<?php echo $res; ?>">Book</a></button></center>

                </div>
                <?php  } ?>
        </div>
    
     <?php
                    require_once('connection.php');


                    $value = $_SESSION['email'];

                    $sql = "select * from student where email='$value'";
                    $name = mysqli_query($con, $sql);
                    $rows = mysqli_fetch_assoc($name);
                    ?>

    </div>
    </section>
    <script src="script.js"> </script>
</body>

</html>