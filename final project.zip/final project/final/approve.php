<?php
require_once('connection.php');

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $bookid = $_GET['id'];
    $sql = "SELECT * FROM bookings WHERE id = $bookid";
    $result = mysqli_query($con, $sql);
    $res = mysqli_fetch_assoc($result);
    $car_id = $res['CarID'];
    $sql2 = "SELECT * FROM cars WHERE CarID = $car_id";
    $carres = mysqli_query($con, $sql2);
    $carresult = mysqli_fetch_assoc($carres);
    $email = $res['email'];
    $carname = $carresult['Brand'];
    if ($carresult['Available'] == 'Y') {
        if ($res['BOOK_STATUS'] == 'APPROVED' || $res['BOOK_STATUS'] == 'RETURNED') {
            echo '<script>alert("ALREADY APPROVED")</script>';
            echo '<script>window.location.href = "bookingadmin.php";</script>';
        } else {
            $query = "UPDATE bookings SET booking_status = 'Confirmed' WHERE id = $bookid";
            $queryy = mysqli_query($con, $query);
            $sql2 = "UPDATE cars SET AVAILABLE = 'N' WHERE CarID = $res[CarID]";
            $query2 = mysqli_query($con, $sql2);

            echo '<script>alert("APPROVED SUCCESSFULLY")</script>';
            echo '<script>window.location.href = "bookingadmin.php";</script>';
        }
    } else {
        echo '<script>alert("CAR IS NOT AVAILABLE")</script>';
        echo '<script>window.location.href = "bookingadmin.php";</script>';
    }
} else {
    echo '<script>alert("Invalid request!")</script>';
    echo '<script>window.location.href = "bookingadmin.php";</script>';
}
?>
